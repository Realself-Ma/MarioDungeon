﻿#ifndef TOTAL_H
#define TOTAL_H

#include <string.h>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "storewindow.h"
#include "ui_storewindow.h"
#include "monsterinfolistitem.h"
#include "monsterinfolist.h"

#include "variables.h"
#include "mt.h"

#include <time.h>
//#include <unistd.h>

#endif // TOTAL_H
